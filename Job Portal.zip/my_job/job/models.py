from django.db import models

# Create your models here.
class UserTable(models.Model):
    email=models.EmailField(max_length=50)
    password=models.CharField(max_length=128)
    otp=models.IntegerField()
    role=models.CharField(max_length=50)
    is_active=models.BooleanField(default=True)
    is_varrified=models.BooleanField(default=False)
    is_created=models.DateField(auto_now_add=True)
    _is_updated=models.DateField(auto_now_add=True)


class Candidate(models.Model):
    user_id=models.ForeignKey(UserTable,on_delete=models.CASCADE)
    firstname=models.CharField(max_length=50)
    lastname=models.CharField(max_length=50)
    contact=models.CharField(max_length=50)
    state=models.CharField(max_length=50)
    city=models.CharField(max_length=50)
    address=models.CharField(max_length=150)
    dob=models.CharField(max_length=20)
    gender=models.CharField(max_length=20)
    min_salary=models.BigIntegerField(default=0)
    max_salary=models.BigIntegerField(null=True,blank=True)
    job_type=models.CharField(max_length=150)
    jobcategory=models.CharField(max_length=150)
    country=models.CharField(max_length=150)
    highestedu=models.CharField(max_length=150)
    experience=models.CharField(max_length=150)
    website=models.CharField(max_length=150)
    shift=models.CharField(max_length=150)
    jobdesc=models.CharField(max_length=500)
    profile_pic=models.ImageField(upload_to="app/img/candidate")


class Company(models.Model):
    user_id=models.ForeignKey(UserTable,on_delete=models.CASCADE)
    firstname=models.CharField(max_length=50)
    lastname=models.CharField(max_length=50)
    company_name=models.CharField(max_length=150,null=True,blank=True)
    state=models.CharField(max_length=50,null=True,blank=True)
    city=models.CharField(max_length=50,null=True,blank=True)
    contact=models.CharField(max_length=50,null=True,blank=True)
    address=models.CharField(max_length=150,null=True,blank=True)


# class JobDetails(models.Model):
#     company_id=models.ForeignKey(Company,on_delete=models.CASCADE,null=False)
#     jobname=models.CharField(max_length=250)
#     companyname=models.CharField(max_length=250)
#     companyaddress=models.CharField(max_length=250)
#     jobdesc=models.TextField(max_length=500) 
#     qualification=models.CharField(max_length=250)
#     resposibility=models.CharField(max_length=250)
#     location=models.CharField(max_length=250)
#     companywebsite=models.CharField(max_length=250)
#     companyemail=models.CharField(max_length=250)
#     companycontact=models.CharField(max_length=50)
#     salary=models.CharField(max_length=250)
#     experience=models.IntegerField()


class JobDetail(models.Model):
    company_id=models.ForeignKey(Company,on_delete=models.CASCADE)
    jobname=models.CharField(max_length=250)
    companyname=models.CharField(max_length=250)
    companyaddress=models.CharField(max_length=250)
    jobdesc=models.TextField(max_length=500) 
    qualification=models.CharField(max_length=250)
    resposibility=models.CharField(max_length=250)
    location=models.CharField(max_length=250)
    companywebsite=models.CharField(max_length=250)
    companyemail=models.CharField(max_length=250)
    companycontact=models.CharField(max_length=50)
    salary=models.CharField(max_length=250)
    experience=models.IntegerField()

class ApplyJob(models.Model):
    candidate=models.ForeignKey(Candidate,on_delete=models.CASCADE)
    job=models.ForeignKey(JobDetail,on_delete=models.CASCADE)
    portfolio=models.CharField(max_length=50)
    min_salary=models.CharField(max_length=250)
    max_salary=models.CharField(max_length=250)
    resume=models.FileField(upload_to="resume")