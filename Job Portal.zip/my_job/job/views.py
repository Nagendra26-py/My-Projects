from django.shortcuts import render,redirect
from job.models import UserTable,Candidate,Company,JobDetail,ApplyJob
from random import randint
import random
from django.core.mail import send_mail
from django.conf import settings
import smtplib
from email.mime.text import MIMEText
from django.contrib import messages
from django.utils.crypto import get_random_string

# Create your views here.

def IndexPage(request):
    return render(request,"index.html")

def SignupPage(request):
    return render(request,"signup.html")

def AboutPage(request):
    return render(request,"about.html")

def Services(request):
    return render(request,"services.html")

def Team(request):
    return render(request,"team.html")

def Contact(request):
    return render(request,"contact.html")

def EmployeesList(request):
    return render(request,"employers-list.html")

def CompanyDetail(request):
    return render(request,"company-detail.html")

def ForgetPassword(request):
    return render(request,"forget_passward.html")

def RegisterUser(request):
    if request.method == "POST":
        role = request.POST.get('role')
        firstname = request.POST.get('firstname')
        lastname = request.POST.get('lastname')
        email = request.POST.get('email')
        password = request.POST.get('password')
        cpassword = request.POST.get('cpassword')

        if UserTable.objects.filter(email=email).exists():
            messages.error(request, "User with this email already exists.")
            return render(request, 'signup.html')
        
        if password != cpassword:
            messages.error(request, "Passwords do not match.")
            return render(request, 'signup.html')
        # Generate and send OTP
        otp = random.randint(100000, 999999)
        subject = "Your OTP for Registration"
        message = f"Your OTP is {otp}."
        send_mail(subject, message, 'nagendrasingh2607@gmail.com', [email])

        # Store OTP in session for verification
        request.session['otp'] = otp
        request.session['email'] = email
        request.session['firstname'] = firstname
        request.session['lastname'] = lastname
        request.session['role'] = role
        request.session['password'] = password

        return redirect('otp')

    return render(request, 'signup.html')

def OTPPage(request):
    return render(request,"otpverify.html")

def Otpverify(request):
    if request.method == "POST":
        entered_otp = request.POST.get('otp')
        if entered_otp == str(request.session.get('otp')):
            email = request.session.get('email')
            password = request.session.get('password')
            role = request.session.get('role')
            user = UserTable.objects.create(
                email=email,
                password=password,
                otp=request.session.get('otp'),
                role=role,
            )
            
            if role == 'Candidate':
                Candidate.objects.create(
                    user_id=user,
                    firstname=request.session.get('firstname'),
                    lastname=request.session.get('lastname'),
                )
            else:
                Company.objects.create(
                    user_id=user,
                    firstname=request.session.get('firstname'),
                    lastname=request.session.get('lastname'),
                )

            del request.session['otp']
            del request.session['email']
            del request.session['firstname']
            del request.session['lastname']
            del request.session['role']

            messages.success(request, "Registration successful!, Login and Update your Profile.")
            return redirect('loginpage')

        else:
            messages.error(request, "Invalid OTP. Please try again.")

    return render(request, 'otpverify.html')
    

def LoginPage(request):
    return render(request,"login.html")

def LoginUser(request):
    if request.method=="POST":
        email=request.POST.get('email')
        password=request.POST.get('password')

        try:
            user = UserTable.objects.get(email=email)
            if user.password == password and user.role == "Candidate":
                try:
                    can = Candidate.objects.get(user_id=user)
                    request.session["id"] = user.id
                    request.session["role"] = user.role
                    request.session["firstname"] = can.firstname
                    request.session["lastname"] = can.lastname
                    request.session["email"] = user.email
                    request.session["password"]=user.password
                    request.session["phone_number"] = can.contact
                    request.session["state"] = can.state
                    request.session["city"] = can.city
                    request.session["address"] = can.address
                    request.session["dob"] = can.dob
                    request.session["gender"] = can.gender
                    request.session["min_sal"] = can.min_salary
                    request.session["max_sal"] = can.max_salary
                    request.session["job_type"] = can.job_type
                    request.session["jobcategory"] = can.jobcategory
                    request.session["country"] = can.country
                    request.session["highestedu"] = can.highestedu
                    request.session["experience"] = can.experience
                    request.session["website"] = can.website
                    request.session["shift"] = can.shift
                    request.session["jobdesc"] = can.jobdesc

                    return redirect("index")
                except Candidate.DoesNotExist:
                    message = "Candidate record not found for this user."
                    return render(request, "login.html", {"msg": message})
                
            elif user.password==password and user.role=="Company":
                try:
                    can = Company.objects.get(user_id=user)
                    request.session["id"] = user.id
                    request.session["role"] = user.role
                    request.session["firstname"] = can.firstname
                    request.session["lastname"] = can.lastname
                    request.session["email"]=user.email
                    request.session["password"]=user.password
                    return redirect("companyindex")
                except Candidate.DoesNotExist:
                        message = "Candidate record not found for this user."
                        return render(request, "login.html", {"msg": message})
            else:
                message="Incorrect Email, Password or Role"
                return render(request,"login.html",{'msg':message})
        except UserTable.DoesNotExist:
            message = "User does not exist"
            return render(request, "login.html", {"msg": message})

                

def ProfilePage(request):
    return render(request,"profile.html",{"user":request.user,"request":request})

def UpdateProfile(request):
    # Check if the user is logged in
    if "id" in request.session and request.session["role"] == "Candidate":
        user_id = request.session["id"]
        
        try:
            user = UserTable.objects.get(id=user_id)
            if user.role == "Candidate":
                try:
                    # Retrieve the Candidate object linked to the user
                    can = Candidate.objects.get(user_id=user)
                    
                    # Update fields with data from the POST request
                    can.contact = request.POST["phone_number"]
                    can.state = request.POST["state"]
                    can.city = request.POST["city"]
                    can.address = request.POST["address"]
                    can.dob = request.POST["dob"]
                    can.gender = request.POST["gender"]
                    can.min_salary = request.POST["min_sal"]
                    can.max_salary = request.POST["max_sal"]
                    can.job_type = request.POST["job_type"]
                    can.jobcategory = request.POST["jobcategory"]
                    can.country = request.POST["country"]
                    can.highestedu = request.POST["hightestedu"]
                    can.experience = request.POST["experience"]
                    can.website = request.POST["website"]
                    can.shift = request.POST["shift"]
                    can.jobdesc = request.POST["jobdesc"]
                    
                    if 'profile_pic' in request.FILES:
                        can.profile_pic = request.FILES["profile_pic"]
                    can.save()
                    return redirect('loginpage',{'msg':"Login to Continue"})
                    
                except Candidate.DoesNotExist:
                    return render(request, "update_profile.html", {"msg": "Candidate profile not found."})
            else:
                return render(request, "update_profile.html", {"msg": "Unauthorized access. User is not a candidate."})
        
        except UserTable.DoesNotExist:
            return render(request, "update_profile.html", {"msg": "User not found."})
    
    else:
        return redirect("login")

def ApplyPage(request,pk):
    user=request.session['id']
    if user:
        cand=Candidate.objects.get(user_id=user)
        job=JobDetail.objects.get(id=pk)
    return render(request,"apply.html",{"user":user,"cand":cand,"job":job})

def ApplyJobs(request,pk):
    user=request.session["id"]
    if user:
        can=Candidate.objects.get(user_id=user)
        job=JobDetail.objects.get(id=pk)
        min_salary=request.POST["min_sal"]
        max_salary=request.POST["max_sal"]
        portfolio=request.POST["portfoliowebsite"]
        resume=request.FILES["resume"]

        newapply=ApplyJob.objects.create(candidate=can,job=job,min_salary=min_salary,max_salary=max_salary,portfolio=portfolio,resume=resume)
        return render(request,"job-list.html",{"msg":"Job apply Successfully"})
    
def CandidateLogout(request):
    request.session.flush()
    return redirect('index')

def ForgetOtp(request):
    return render(request,"otpverify1.html")

def ForgetPassword(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        otp = random.randint(100000, 999999)
        subject = "Your OTP for Registration"
        message = f"Your OTP is {otp}."
        send_mail(subject, message, 'nagendrasingh2607@gmail.com', [email])

        request.session['otp'] = otp
        request.session['email'] = email
        
        messages.success(request, 'An OTP has been sent to your email.')
        return redirect('otpverify')
       
    else:
        return render(request, 'forget_passward.html')

def OtpVerify1(request):
    if request.method == 'POST':
        enter_otp=request.POST.get("otp")

        if enter_otp==str(request.session.get('otp')):
            return render(request,"new_password.html")
            
        else:
            messages.error(request, 'Invalid OTP. Please try again.')

    return render(request, 'otpverify1.html')

def NewPassword(request):
    return render(request,"new_password.html")

def NewPass(request):
    if request.method=="POST":
        email = request.session.get("email")
        new_password=request.POST.get('new_password')
        user=UserTable.objects.get(email=email)
        user.password=new_password
        user.save()
        return render(request,"login.html",{"msg":"Password changed"})


####################company_programs####################

def CompanyIndex(request):
    return render(request,"company/index.html")

def CompanyProfile(request):
    return render(request,"company/profile.html")


def CompanyProfileUpdate(request):
    if 'id' in request.session and request.session['role'] == 'Company':
        user_id=request.session["id"]
        try:
            user = UserTable.objects.get(id=user_id)
            

            if user.role=="Company":
                if request.method=="POST":

                    try:
                        can=Company.objects.get(user_id=user)
                        can.company_name=request.POST.get("companyname")
                        can.state=request.POST.get("state")
                        can.city=request.POST.get("city")
                        can.contact=request.POST.get("companycontact")
                        can.address=request.POST.get("companyaddress")
                        can.save()
                        return redirect("companyindex")
                    except Company.DoesNotExist:
                        return render(request,"company/profile.html")
                
                else:
                    pass
            else:
                pass

        except UserTable.DoesNotExist:
            return render(request,"comapny/profile.html")

    else:
        pass

def JobPostPage(request):
    return render(request,"company/jobpost.html")


def JobDetailSubmit(request):
    if request.method == "POST":
        user_id = request.session.get('id')
        if user_id is None:
            return render(request, 'login.html', {'msg': "Please log in to post a job."})

        try:
            company = Company.objects.get(user_id=user_id)
        except Company.DoesNotExist:
            return render(request, 'job_post.html', {'msg': "Company not found."})

        job_detail = JobDetail(
            company_id=company,
            jobname=request.POST['jobname'],
            companyname=request.POST['companyname'],
            companyaddress=request.POST['companyaddress'],
            jobdesc=request.POST['jobdesc'],
            qualification=request.POST['qualification'],
            resposibility=request.POST['resposibility'],
            location=request.POST['location'],
            companywebsite=request.POST['companywebsite'],
            companyemail=request.POST['companyemail'],
            companycontact=request.POST['companycontact'],
            salary=request.POST['salary'],
            experience=int(request.POST['experience'])
        )
        job_detail.save()

        return render(request,'company/jobpost.html',{"msg":"Job Post Successfully"})

    return render(request, 'company/jobpost.html')

def JobPostList(request):
    all_job=JobDetail.objects.all()
    return render(request,"company/jobpostlist.html",{'all_job':all_job})

def CandidateJobPostList(request):
    all_job=JobDetail.objects.all()
    return render(request,"job-list.html",{'all_job':all_job})

def JobAppltList(request):
    all_job=ApplyJob.objects.all()
    return render(request,"company/applyjoblist.html",{"all_job":all_job})

def CompanyLogout(request):
    request.session.flush()
    return redirect('index')
