from django.urls import path,include
from .import views

urlpatterns = [
    path('',views.IndexPage,name="index"),
    path('signup/',views.SignupPage,name="signup"),
    path('register/',views.RegisterUser,name="register"),
    path('otppage/',views.OTPPage,name=" otppage"),
    path('otp/',views.Otpverify,name="otp"),
    path('loginpage/',views.LoginPage,name="loginpage"),
    path('loginuser/',views.LoginUser,name="login"),
    path('profilepage/',views.ProfilePage,name="profile"),
    path('updateprofile/',views.UpdateProfile,name="updateprofile"),


    ####################company_programs####################
    path('companyindex',views.CompanyIndex,name="companyindex"),
    path('companyprofile/',views.CompanyProfile,name="companyprofile"),
    path('company/profile/update/',views.CompanyProfileUpdate,name="companyprofileupdate"),
    path('jobpostpage/',views.JobPostPage,name="jobpostpage"),
    path('jobpost/',views.JobDetailSubmit,name="jobpost"),
]