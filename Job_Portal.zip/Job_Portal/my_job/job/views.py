from django.shortcuts import render,redirect
from job.models import UserTable
from job.models import Candidate
from job.models import Company
from job.models import JobDetails
from random import randint
# Create your views here.

def IndexPage(request):
    return render(request,"index.html")

def SignupPage(request):
    return render(request,"signup.html")

def RegisterUser(request):
    if request.POST["role"]=="Candidate":
        role=request.POST["role"]
        fname=request.POST["firstname"]
        lname=request.POST["lastname"]
        email=request.POST["email"]
        password=request.POST["password"]
        cpassword=request.POST["cpassword"]

        user=UserTable.objects.filter(email=email)
        
        if user:
            message="User Already Exist"
            return render(request,"signup.html",{'msg':message})
        else:
            if password==cpassword:
                otp=randint(100000,999999)
                newuser=UserTable.objects.create(role=role,otp=otp,email=email,password=password)
                newcand=Candidate.objects.create(user_id=newuser,firstname=fname,lastname=lname)
                return render(request,"otpverify.html",{"email":email})
            else:
                return render(request,"signup.html",{"msg":"Both Password does not match"})
    else:
        if request.POST["role"]=="Company":
            role=request.POST["role"]
            fname=request.POST["firstname"]
            lname=request.POST["lastname"]
            email=request.POST["email"]
            password=request.POST["password"]
            cpassword=request.POST["cpassword"]

            user=UserTable.objects.filter(email=email)

            if user:
                message="User already Exist"
                return render(request,"signup.html",{"msg":message})
            else:
                if password==cpassword:
                    otp=randint(100000,999999)
                    newuser=UserTable.objects.create(role=role,otp=otp,email=email,password=password)
                    newcand=Company.objects.create(user_id=newuser,firstname=fname,lastname=lname)
                    return render(request,"otpverify.html",{"email":email})
                else:
                    return render(request,"signup,html",{"msg":"Both Password does not match"})


def OTPPage(request):
    return render(request,"otpverify.html")

def Otpverify(request):
    email=request.POST["email"]
    otp=request.POST["otp"]

    user=UserTable.objects.get(email=email)
    
    if user:
        if str(user.otp)==otp:
            message="Otp verify successfully and Registration Complete."
            return render(request,"login.html",{"msg":message})
        else:
            message="Otp is incorrect"
            return render(request,"otpverify.html",{"msg":message})
    else:
        return render(request,"signup.html")
    

def LoginPage(request):
    return render(request,"login.html")

def LoginUser(request):
    if request.POST["role"] == "Candidate":
        email = request.POST["email"]
        password = request.POST["password"]

        try:
            user = UserTable.objects.get(email=email)
            if user.password == password and user.role == "Candidate":
                request.session.flush()
                try:
                    can = Candidate.objects.get(user_id=user)
                    request.session["id"] = user.id
                    request.session["role"] = user.role
                    request.session["firstname"] = can.firstname
                    request.session["lastname"] = can.lastname
                    request.session["email"] = user.email
                    request.session["phone_number"] = can.contact
                    request.session["state"] = can.state
                    request.session["city"] = can.city
                    request.session["address"] = can.address
                    request.session["dob"] = can.dob
                    request.session["gender"] = can.gender
                    request.session["min_sal"] = can.min_salary
                    request.session["max_sal"] = can.max_salary
                    request.session["job_type"] = can.job_type
                    request.session["jobcategory"] = can.jobcategory
                    request.session["country"] = can.country
                    request.session["highestedu"] = can.highestedu
                    request.session["experience"] = can.experience
                    request.session["website"] = can.website
                    request.session["shift"] = can.shift
                    request.session["jobdesc"] = can.jobdesc

                    return redirect("index")
                except Candidate.DoesNotExist:
                    message = "Candidate record not found for this user."
                    return render(request, "login.html", {"msg": message})
            else:
                message = "Incorrect Password"
                return render(request, "login.html", {"msg": message})
        except UserTable.DoesNotExist:
            message = "User does not exist"
            return render(request, "login.html", {"msg": message})
    else:
        if request.POST["role"] == "Company":
            email = request.POST["email"]
            password = request.POST["password"]

            try:
                user=UserTable.objects.get(email=email)
                if user.password==password and user.role=="Company":
                    request.session.flush()
                    try:
                        can = Company.objects.get(user_id=user)
                        request.session["id"] = user.id
                        request.session["role"] = user.role
                        request.session["firstname"] = can.firstname
                        request.session["lastname"] = can.lastname
                        return redirect("companyindex")
                    except Candidate.DoesNotExist:
                        message = "Candidate record not found for this user."
                        return render(request, "login.html", {"msg": message})
                else:
                    message="Incorrect Password"
                    return render(request,"login.html",{'msg':message})

            except UserTable.DoesNotExist:
                message="User does not exist"
                return render(request,"login.html",{"msg":message})
        
        else:
            pass
    



    # if request.POST["role"]=="Candidate":
    #     email=request.POST["email"]
    #     password=request.POST["password"]

    #     user=UserTable.objects.get(email=email)

    #     if user:
    #         if user.password==password and user.role=="Candidate":
    #             can=Candidate.objects.get(user_id=user)
    #             request.session["id"]=user.id
    #             request.session["role"]=user.role
    #             request.session["firstname"]=can.firstname
    #             request.session["lastname"]=can.lastname
    #             request.session["email"]=user.email
    #             return redirect("index")
    #         else:
    #             message="Incorrect Password"
    #             return render(request,"login.html",{"msg":message})
    # else:
    #     message="User does not Exist"
    #     return render(request,"login.html",{"msg":message})
    
    # if request.POST["role"]=="Company":
    #     email=request.POST["email"]
    #     password=request.POST["password"]

    #     user=UserTable.objects.get(email=email)

    #     if user:
    #         if user.password==password and user.role=="Company":
    #             can=Company.objects.get(user_id=user)
    #             request.session["id"]=user.id
    #             request.session["role"]=user.role
    #             request.session["firstname"]=can.firstname
    #             request.session["lastname"]=can.lastname
    #             request.session["email"]=user.email
    #             return redirect("index")
    #         else:
    #             message="Incorrect Password"
    #             return render(request,"login.html",{"msg":message})
    # else:
    #     message="User does not Exist"
    #     return render(request,"login.html",{"msg":message})
            

def ProfilePage(request):
    return render(request,"profile.html")

# def UpdateProfile(request):
#     user=UserTable.objects.get(id=request.session['user_id'])
#     if user.role=="Candidate":
#         can=Candidate.objects.get(user_id=user)
#         can["contact"]=request.POST["phone_number"]
#         can["state"]=request.POST["state"]
#         can["city"]=request.POST["city"]
#         can["address"]=request.POST["address"]
#         can["dob"]=request.POST["dob"]
#         can["gender"]=request.POST["gender"]
#         can["min_salary"]=request.POST["min_sal"]
#         can["max_salary"]=request.POST["max_sal"]
#         can["job_type"]=request.POST["job_type"]
#         can["jobcategory"]=request.POST["jobcategory"]
#         can["country"]=request.POST["country"]
#         can["hightestedu"]=request.POST["hightestedu"]
#         can["experience"]=request.POST["experience"]
#         can["website"]=request.POST["website"]
#         can["shift"]=request.POST["shift"]
#         can["jobdesc"]=request.POST["jobdesc"]
#         can["profile_pic"]=request.FILE["image"]

#         can.save()
        

def UpdateProfile(request):
    # Check if the user is logged in
    if "id" in request.session and request.session["role"] == "Candidate":
        user_id = request.session["id"]
        
        try:
            # Retrieve the user from the UserTable
            user = UserTable.objects.get(id=user_id)
            
            # Ensure the user is a Candidate
            if user.role == "Candidate":
                try:
                    # Retrieve the Candidate object linked to the user
                    can = Candidate.objects.get(user_id=user)
                    
                    # Update fields with data from the POST request
                    can.contact = request.POST["phone_number"]
                    can.state = request.POST["state"]
                    can.city = request.POST["city"]
                    can.address = request.POST["address"]
                    can.dob = request.POST["dob"]
                    can.gender = request.POST["gender"]
                    can.min_salary = request.POST["min_sal"]
                    can.max_salary = request.POST["max_sal"]
                    can.job_type = request.POST["job_type"]
                    can.jobcategory = request.POST["jobcategory"]
                    can.country = request.POST["country"]
                    can.highestedu = request.POST["hightestedu"]
                    can.experience = request.POST["experience"]
                    can.website = request.POST["website"]
                    can.shift = request.POST["shift"]
                    can.jobdesc = request.POST["jobdesc"]
                    
                    # Handle profile picture upload
                    if 'profile_pic' in request.FILES:
                        can.profile_pic = request.FILES["profile_pic"]

                    # Save the updated Candidate profile
                    can.save()
                    
                    # Redirect to a success page or profile page
                    return redirect('loginpage',{'msg':"Login to Continue"})
                    
                except Candidate.DoesNotExist:
                    # If the Candidate record is not found
                    return render(request, "update_profile.html", {"msg": "Candidate profile not found."})
            else:
                return render(request, "update_profile.html", {"msg": "Unauthorized access. User is not a candidate."})
        
        except UserTable.DoesNotExist:
            # If the UserTable record is not found
            return render(request, "update_profile.html", {"msg": "User not found."})
    
    else:
        # If no user is logged in, redirect to login page
        return redirect("login")



####################company_programs####################

def CompanyIndex(request):
    return render(request,"company/index.html")

def CompanyProfile(request):
    return render(request,"company/profile.html")


def CompanyProfileUpdate(request):
    # Ensure the user is logged in and is a company
    if 'id' in request.session and request.session['role'] == 'Company':
        user_id=request.session["id"]
        try:
            # Retrieve the user from the UserTable
            user = UserTable.objects.get(id=user_id)

            if user.role=="Company":
                try:
                    can=Company.objects.get(user_id=user)
                    can.company_name=request.POST.get("companyname")
                    can.state=request.POST.get("state")
                    can.city=request.POST.get("city")
                    can.contact=request.POST.get("companycontact")
                    can.address=request.POST.get("companyaddress")
                    if 'logo_pic' in request.FILES:
                        can.logo_pic=request.FILES["logoimage"]

                    can.save()
                    return redirect("companyindex")
                except Company.DoesNotExist:
                    return render(request,"company/profile.html")
            else:
                pass

        except UserTable.DoesNotExist:
            return render(request,"comapny/profile.html")

    else:
        pass

def JobPostPage(request):
    return render(request,"company/jobpost.html")

def JobDetailSubmit(request):
    user=UserTable.objects.get(id=request.session.id)

    if user.role=="Company":
        if request.method == "POST":
            comp=Company.objects.get(user_id=user)
            jobname=request.POST["jobname"]
            companyname=request.POST["companyname"]
            companyaddress=request.POST["companyaddress"]
            companydesc=request.POST["companydesc"]
            qualification=request.POST["qualification"]
            resposibility=request.POST["resposibility"]
            location=request.POST["location"]
            companywebsite=request.POST["companywebsite"]
            companyemail=request.POST["companyemail"]
            companycontact=request.POST["companycontact"]
            salary=request.POST["salary"]
            experience=request.POST["experience"]

            newjob=JobDetails.objects.create(company_id=comp,jobname=jobname,companyname=companyname,companyaddress=companyaddress,companydesc=companydesc,qualification=qualification,resposibility=resposibility,location=location,companywebsite=companywebsite,companyemail=companyemail,companycontact=companycontact,salary=salary,experience=experience)

            return render(request,"company/index.html")
        else:
            pass
    else:
        pass
