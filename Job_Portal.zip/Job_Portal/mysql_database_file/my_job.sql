/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19  Distrib 10.5.26-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: my_job
-- ------------------------------------------------------
-- Server version	10.5.26-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_group_permissio_permission_id_84c5c92e_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permission_content_type_id_2f476e4b_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add user table',7,'add_usertable'),(26,'Can change user table',7,'change_usertable'),(27,'Can delete user table',7,'delete_usertable'),(28,'Can view user table',7,'view_usertable'),(29,'Can add company',8,'add_company'),(30,'Can change company',8,'change_company'),(31,'Can delete company',8,'delete_company'),(32,'Can view company',8,'view_company'),(33,'Can add candidate',9,'add_candidate'),(34,'Can change candidate',9,'change_candidate'),(35,'Can delete candidate',9,'delete_candidate'),(36,'Can view candidate',9,'view_candidate'),(37,'Can add job details',10,'add_jobdetails'),(38,'Can change job details',10,'change_jobdetails'),(39,'Can delete job details',10,'delete_jobdetails'),(40,'Can view job details',10,'view_jobdetails');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` (`permission_id`),
  CONSTRAINT `auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext DEFAULT NULL,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL CHECK (`action_flag` >= 0),
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb_fk_django_co` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin_log_content_type_id_c4bce8eb_fk_django_co` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(3,'auth','group'),(2,'auth','permission'),(4,'auth','user'),(5,'contenttypes','contenttype'),(9,'job','candidate'),(8,'job','company'),(10,'job','jobdetails'),(7,'job','usertable'),(6,'sessions','session');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2024-10-15 20:41:22.943624'),(2,'auth','0001_initial','2024-10-15 20:41:23.163840'),(3,'admin','0001_initial','2024-10-15 20:41:23.259221'),(4,'admin','0002_logentry_remove_auto_add','2024-10-15 20:41:23.290517'),(5,'admin','0003_logentry_add_action_flag_choices','2024-10-15 20:41:23.290517'),(6,'contenttypes','0002_remove_content_type_name','2024-10-15 20:41:23.338001'),(7,'auth','0002_alter_permission_name_max_length','2024-10-15 20:41:23.353853'),(8,'auth','0003_alter_user_email_max_length','2024-10-15 20:41:23.382827'),(9,'auth','0004_alter_user_username_opts','2024-10-15 20:41:23.385736'),(10,'auth','0005_alter_user_last_login_null','2024-10-15 20:41:23.418516'),(11,'auth','0006_require_contenttypes_0002','2024-10-15 20:41:23.418516'),(12,'auth','0007_alter_validators_add_error_messages','2024-10-15 20:41:23.433790'),(13,'auth','0008_alter_user_username_max_length','2024-10-15 20:41:23.450268'),(14,'auth','0009_alter_user_last_name_max_length','2024-10-15 20:41:23.465395'),(15,'auth','0010_alter_group_name_max_length','2024-10-15 20:41:23.481051'),(16,'auth','0011_update_proxy_permissions','2024-10-15 20:41:23.485223'),(17,'auth','0012_alter_user_first_name_max_length','2024-10-15 20:41:23.496813'),(18,'job','0001_initial','2024-10-15 20:41:23.607360'),(19,'sessions','0001_initial','2024-10-15 20:41:23.639106'),(20,'job','0002_alter_candidate_max_salary_and_more','2024-10-15 20:45:05.628722'),(21,'job','0003_alter_company_company_name','2024-10-18 14:11:59.068459'),(22,'job','0004_alter_company_address_alter_company_city_and_more','2024-10-18 14:12:56.083926'),(23,'job','0005_jobdetails','2024-10-19 06:14:33.676541'),(24,'job','0006_jobdetails_company_id','2024-10-19 09:23:30.088429');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('k9wpf7zq9beggtpz6pdwg6mfnvfb40o0','.eJyrVspMUbIy1VEqys9JVbJScs7PLUjMq1TSUUrLLCouyUvMBYl65-cm5gDFchLhQsGJGaVKtQB_oRRv:1t21X6:B5l4PPR761xkVAsysnjHrU2xJAiomJ2X2b_Ify1epVg','2024-11-02 04:57:44.246877'),('or2d8ordoar0cnuy178pekiwbiwcdzqo','.eJyrVspMUbIy0VEqys9JVbJScs7PLUjMq1TSUUrLLCouyUvMBYkG5wMZQLGcRIRQRmJRbqJSLQCq3RVD:1t1nk7:iNvDmqN7-ZLt-d0PdFUlP662UckjW1gBqrpmqinTn9E','2024-11-01 14:14:15.500129'),('poo60qgvap8962aaensl844yvs0ta8x3','.eJyrVspMUbIy0VEqys9JVbJScs7PLUjMq1TSUUrLLCouyUvMBYkG5wMZQLGcRIRQRmJRbqJSLQCq3RVD:1t1nmy:Dv2LXP6am5B4cP21K7wX0okOTuSIywoqNdJe3tJCU7o','2024-11-01 14:17:12.671539');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_candidate`
--

DROP TABLE IF EXISTS `job_candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_candidate` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `contact` varchar(50) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `address` varchar(150) NOT NULL,
  `dob` varchar(20) NOT NULL,
  `gender` varchar(20) NOT NULL,
  `min_salary` bigint(20) NOT NULL,
  `max_salary` bigint(20) DEFAULT NULL,
  `job_type` varchar(150) NOT NULL,
  `jobcategory` varchar(150) NOT NULL,
  `country` varchar(150) NOT NULL,
  `highestedu` varchar(150) NOT NULL,
  `experience` varchar(150) NOT NULL,
  `website` varchar(150) NOT NULL,
  `shift` varchar(150) NOT NULL,
  `jobdesc` varchar(500) NOT NULL,
  `profile_pic` varchar(100) NOT NULL,
  `user_id_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_candidate_user_id_id_a96a45eb_fk_job_usertable_id` (`user_id_id`),
  CONSTRAINT `job_candidate_user_id_id_a96a45eb_fk_job_usertable_id` FOREIGN KEY (`user_id_id`) REFERENCES `job_usertable` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_candidate`
--

LOCK TABLES `job_candidate` WRITE;
/*!40000 ALTER TABLE `job_candidate` DISABLE KEYS */;
INSERT INTO `job_candidate` VALUES (1,'Nagendra','Singh','00000000000','MP','Indore','Mig 20 indore','25/08/2020','Male',50000,80000,'Full Time','Backend Developer','India','Graduate','15','www.google.com','Day','I\'m Python Backend Developer','',2),(2,'rahul','sharma','810755587','MP','Bhopal','mig 18 bhopal','26/07/2025','Male',5000,40000,'Full Time','Python Developer','India','Graduate','10','www.google.com','Morning','I\'m Python developer','',3);
/*!40000 ALTER TABLE `job_candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_company`
--

DROP TABLE IF EXISTS `job_company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_company` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(50) NOT NULL,
  `lastname` varchar(50) NOT NULL,
  `company_name` varchar(150) DEFAULT NULL,
  `state` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `logo_pic` varchar(100) NOT NULL,
  `user_id_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `job_company_user_id_id_104b8d7a_fk_job_usertable_id` (`user_id_id`),
  CONSTRAINT `job_company_user_id_id_104b8d7a_fk_job_usertable_id` FOREIGN KEY (`user_id_id`) REFERENCES `job_usertable` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_company`
--

LOCK TABLES `job_company` WRITE;
/*!40000 ALTER TABLE `job_company` DISABLE KEYS */;
INSERT INTO `job_company` VALUES (1,'Sonam','Sharma',NULL,NULL,NULL,NULL,NULL,'app/img/company',4),(2,'Komal','Sahu',NULL,NULL,NULL,NULL,NULL,'app/img/company',5);
/*!40000 ALTER TABLE `job_company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_jobdetails`
--

DROP TABLE IF EXISTS `job_jobdetails`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_jobdetails` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `jobname` varchar(250) NOT NULL,
  `companyname` varchar(250) NOT NULL,
  `companyaddress` varchar(250) NOT NULL,
  `jobdesc` longtext NOT NULL,
  `qualification` varchar(250) NOT NULL,
  `resposibility` varchar(250) NOT NULL,
  `location` varchar(250) NOT NULL,
  `companywebsite` varchar(250) NOT NULL,
  `companyemail` varchar(250) NOT NULL,
  `companycontact` varchar(50) NOT NULL,
  `salary` varchar(250) NOT NULL,
  `experience` int(11) NOT NULL,
  `company_id_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `job_jobdetails_company_id_id_c1958078_fk_job_company_id` (`company_id_id`),
  CONSTRAINT `job_jobdetails_company_id_id_c1958078_fk_job_company_id` FOREIGN KEY (`company_id_id`) REFERENCES `job_company` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_jobdetails`
--

LOCK TABLES `job_jobdetails` WRITE;
/*!40000 ALTER TABLE `job_jobdetails` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_jobdetails` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_usertable`
--

DROP TABLE IF EXISTS `job_usertable`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_usertable` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `otp` int(11) NOT NULL,
  `role` varchar(50) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `is_varrified` tinyint(1) NOT NULL,
  `is_created` date NOT NULL,
  `_is_updated` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_usertable`
--

LOCK TABLES `job_usertable` WRITE;
/*!40000 ALTER TABLE `job_usertable` DISABLE KEYS */;
INSERT INTO `job_usertable` VALUES (1,'palak@gmail.com','palak123',432234,'Candidate',1,0,'2024-10-16','2024-10-16'),(2,'nagendra@gmail.com','nagendra123',824412,'Candidate',1,0,'2024-10-16','2024-10-16'),(3,'rahul@gmail.com','rahul123',336607,'Candidate',1,0,'2024-10-16','2024-10-16'),(4,'sonam@gmail.com','sonam123',955266,'Company',1,0,'2024-10-17','2024-10-17'),(5,'komal@gmail.com','komal123',377827,'Company',1,0,'2024-10-18','2024-10-18');
/*!40000 ALTER TABLE `job_usertable` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-10-20 12:49:31
