from django.contrib import admin
from .models import Author, Book, BorrowRecord


class AuthorAdmin(admin.ModelAdmin):
    list_display = ('name', 'email')
    search_fields = ('name', 'email')
    list_per_page = 25


class BookAdmin(admin.ModelAdmin):
    list_display = ('title', 'genre', 'published_date', 'author')
    search_fields = ('title', 'genre', 'author__name')
    list_filter = ('genre', 'published_date')
    date_hierarchy = 'published_date'
    list_per_page = 25

class BorrowRecordAdmin(admin.ModelAdmin):
    list_display = ('user_name', 'book', 'borrow_date', 'return_date')
    search_fields = ('user_name', 'book__title')
    list_filter = ('borrow_date', 'return_date')
    date_hierarchy = 'borrow_date'
    list_per_page = 25

admin.site.register(Book,BookAdmin)
admin.site.register(Author,AuthorAdmin)
admin.site.register(BorrowRecord,BorrowRecordAdmin)