from django.urls import path
from .views import *

urlpatterns = [
    path('', home_view, name='home'),
    path('add-author/', AuthorCreateView.as_view(), name='add-author'),
    path('authors/', AuthorListView.as_view(), name='author-list'),

    path('add-book/', BookCreateView.as_view(), name='add-book'),
    path('books/', BookListView.as_view(), name='book-list'),

    path('add-borrow/', BorrowRecordCreateView.as_view(), name='add-borrow'),
    path('borrows/', BorrowRecordListView.as_view(), name='borrow-list'),

]
