from django.shortcuts import render
from django.views.generic import CreateView, ListView
from django.urls import reverse_lazy
from .models import Author, Book, BorrowRecord
from .forms import AuthorForm, BookForm, BorrowRecordForm


# Create your views here.

def home_view(request):
    return render(request, 'library/home.html')

class AuthorCreateView(CreateView):
    model = Author
    form_class = AuthorForm
    template_name = 'library/author_form.html'
    success_url = reverse_lazy('author-list')

class BookCreateView(CreateView):
    model = Book
    form_class = BookForm
    template_name = 'library/book_form.html'
    success_url = reverse_lazy('book-list')

    def form_invalid(self, form):
        print("Form is invalid")
        print(form.errors)
        return super().form_invalid(form)

    def form_valid(self, form):
        print("Form is valid")
        return super().form_valid(form)

class BorrowRecordCreateView(CreateView):
    model = BorrowRecord
    form_class = BorrowRecordForm
    template_name = 'library/borrow_form.html'
    success_url = reverse_lazy('borrow-list')

# List Views with Pagination
class AuthorListView(ListView):
    model = Author
    template_name = 'authors_list.html'
    context_object_name = 'authors'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['field_names'] = [field.name for field in Author._meta.fields]
        return context

class BookListView(ListView):
    model = Book
    template_name = 'library/book_list.html'
    paginate_by = 5
    context_object_name = 'object_list'  # Make sure this matches your template

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['field_names'] = [field.name for field in Book._meta.fields]
        return context


class BorrowRecordListView(ListView):
    model = BorrowRecord
    template_name = 'library/borrow_list.html'
    paginate_by = 5
    context_object_name = 'object_list'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['field_names'] = [field.name for field in BorrowRecord._meta.fields]
        return context

