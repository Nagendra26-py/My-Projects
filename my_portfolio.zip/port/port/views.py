from django.shortcuts import render

def home(request):
    return render(request,'portfpolio.html')

def work(request):
    return render(request,'work.html')

def contact(request):
    return render(request,'contact.html')

def service(request):
    return render(request,'service.html')